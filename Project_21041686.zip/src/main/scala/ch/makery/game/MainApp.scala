package ch.makery.game

import ch.makery.game.util.Database
import ch.makery.game.model.{Player, Warrior}
import ch.makery.game.view.{InputNamePrompt, Scene1Controller, Scene2Controller, Scene3Controller, Scene4Controller, Scene4bController, Scene5Controller, Scene6Controller, Scene6bController, Scene7Controller, Scene8Controller, Scene8bController, Scene8cController}
import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.scene.Scene
import scalafx.Includes._
import scalafxml.core.{FXMLLoader, FXMLView, NoDependencyResolver}
import javafx.{scene => jfxs}
import scalafx.scene.image.Image
import scalafx.collections.ObservableBuffer
import scalafx.scene.media.{Media, MediaPlayer}
import scalafx.stage.{Modality, Stage}


object MainApp extends JFXApp {
  //initialize database
  Database.setupDB()
  /**
   * The data as an observable list of Players.
   */
  val playerData = new ObservableBuffer[Player]()

  /**
   * Constructor
   */
  //assign all person into playersData array
  playerData ++= Player.getAllPlayers

  var player1 = new Warrior ()


  // Transform path of RootLayout.fxml to URI for resource location.
  val rootResource = getClass.getResource("view/RootLayout.fxml")
  // Initialize the loader object.
  val loader = new FXMLLoader(rootResource, NoDependencyResolver)
  // Load root layout from fxml file.
  loader.load();
  // Retrieve the root component BorderPane from the FXML
  val roots = loader.getRoot[jfxs.layout.BorderPane]

  // Initialize stage
  stage = new PrimaryStage {
    title = "Dragon Warrior"
    scene = new Scene {
      //stylesheets += getClass.getResource("view/Style.css").toString()
      root = roots
    }
    icons += new Image(getClass.getResourceAsStream("/images/icon.png"))
    val bgm = new Media(getClass.getResource("/sound/ThemeSong.wav").toExternalForm)
    val bgmPlayer = new MediaPlayer(bgm)
    bgmPlayer.cycleCount = MediaPlayer.Indefinite // Play the media repeatedly
    bgmPlayer.play()
  }

  def showLandingPage() = {
    val resource = getClass.getResource("view/LandingPage.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)
  }

  def showInformationPage() = {
    val resource = getClass.getResource("view/InformationPage.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)
  }

  def showWarriorBoard() = {
    val resource = getClass.getResource("view/WarriorBoard.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)
  }

  def playScene1(): Unit = {
    val resource = getClass.getResource("view/Scene1.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control1 = loader.getController[Scene1Controller#Controller]
    control1.playS1()
  }

  def switchScene2(): Unit = {
    val resource = getClass.getResource("view/Scene2.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control2 = loader.getController[Scene2Controller#Controller]
    control2.playS2()
  }

  def switchScene3(): Unit = {
    val resource = getClass.getResource("view/Scene3.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control3 = loader.getController[Scene3Controller#Controller]
    control3.playS3()
  }

  def switchScene4(): Unit = {
    val resource = getClass.getResource("view/Scene4.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control4 = loader.getController[Scene4Controller#Controller]
    control4.playS4()
  }

  def switchScene4b(): Unit = {
    val resource = getClass.getResource("view/Scene4b.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control4b = loader.getController[Scene4bController#Controller]
    control4b.playS4b()
  }

  def switchScene5(): Unit = {
    val resource = getClass.getResource("view/Scene5_AskName.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control5 = loader.getController[Scene5Controller#Controller]
    control5.playS5()
  }

  def showDialog (player: Player): Boolean = {
    val resource = getClass.getResourceAsStream("view/InputNameDialog.fxml")
    val loader = new FXMLLoader(null, NoDependencyResolver)
    loader.load(resource)
    val roots = loader.getRoot[javafx.scene.Parent]
    val controlInput = loader.getController[InputNamePrompt#Controller]

    val dialog = new Stage() {
      title = ": Your majesty, my name is"
      initModality(Modality.APPLICATION_MODAL)
      initOwner(stage)
      scene = new Scene {
        //stylesheets += getClass.getResource("view/InputNameStyle.css").toString
        root = roots
      }
      icons += new Image(getClass.getResourceAsStream("/images/Warrior/warriorIcon.png"))
    }
    controlInput.dialogStage = dialog
    controlInput.player = player

    // Show the dialog and wait for it to be closed
    dialog.showAndWait()

    // Return a result indicating whether the dialog was closed with OK button
    controlInput.okClicked
  }


  def showGame(): Unit = {
    val resource = getClass.getResource("view/Gameplay.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)
  }

  def switchScene6(): Unit = {
    val resource = getClass.getResource("view/Scene6.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control6 = loader.getController[Scene6Controller#Controller]
    control6.playS6()
  }

  def switchScene6b(): Unit = {
    val resource = getClass.getResource("view/Scene6b.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control6b = loader.getController[Scene6bController#Controller]
    control6b.playS6b()
  }

  def switchScene7(): Unit = {
    val resource = getClass.getResource("view/Scene7.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control7 = loader.getController[Scene7Controller#Controller]
    control7.playS7()
  }

  def switchScene8(): Unit = {
    val resource = getClass.getResource("view/Scene8.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control8 = loader.getController[Scene8Controller#Controller]
    control8.playS8()
  }

  def switchScene8b(): Unit = {
    val resource = getClass.getResource("view/Scene8b.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control8b = loader.getController[Scene8bController#Controller]
    control8b.playS8b()
  }

  def switchScene8c(): Unit = {
    val resource = getClass.getResource("view/Scene8c.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)

    val control8c = loader.getController[Scene8cController#Controller]
    control8c.playS8c()
  }

  def startGame (): Unit = {
    val resource = getClass.getResource("view/Gameplay.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)
  }

  def showEndingPage(): Unit = {
    val resource = getClass.getResource("view/EndingPage.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)
  }

  showLandingPage()
}
