package ch.makery.game.model

import ch.makery.game.MainApp
import scalafx.animation.{KeyFrame, Timeline}
import scalafx.scene.control.Alert
import scalafx.scene.control.Alert.AlertType
import scalafx.scene.image.ImageView
import scalafx.scene.image.Image
import scalafx.util.Duration

class Warrior extends Character {
  //Warrior walking behavior
  def walk(npcImage: ImageView, distance: Double, cycleCount: Int): Unit = {
    val walkFrames: List[Image] = List(
      new Image(getClass.getResourceAsStream("/images/Warrior/walk1.png")),
      new Image(getClass.getResourceAsStream("/images/Warrior/walk2.png")),
      new Image(getClass.getResourceAsStream("/images/Warrior/walk3.png")),
      new Image(getClass.getResourceAsStream("/images/Warrior/walk4.png"))
    )

    val frameDuration = Duration(400)

    val walking = new Timeline {
      keyFrames = walkFrames.zipWithIndex.map {
        case (frame, index) =>
          KeyFrame(frameDuration * (index + 1), onFinished = { _ =>
            npcImage.image = frame
            npcImage.translateX = npcImage.translateX() - distance
          })
      }
    }

    walking.cycleCount = cycleCount
    walking.play()
  }

  def giveInstruction () = {
    val alert = new Alert(AlertType.Information) {
      initOwner(MainApp.stage)
      title = "To be a Dragon Warrior...."
      headerText = "Aim and fire the Dragon with your mouse."
      contentText = "Make sure you score the points to full in 30s."
    }
    alert.showAndWait() // Wait for the alert box to be closed
    MainApp.startGame() // Assuming startGame() is the method to switch scenes
  }
}
