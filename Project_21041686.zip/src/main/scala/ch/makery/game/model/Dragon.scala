package ch.makery.game.model

import scalafx.animation.{Animation, Interpolator, KeyFrame, RotateTransition, ScaleTransition, Timeline, TranslateTransition}
import scalafx.scene.CacheHint.Rotate
import scalafx.scene.image.ImageView
import scalafx.scene.image.Image
import scalafx.util.Duration

import scala.util.Random

class Dragon {

  def fly (npcImage: ImageView): Unit = {
    val dragonFaceLeft = new Image(getClass.getResourceAsStream("/images/Dragon/dragonL.png"))

    val frameDuration = Duration(4000)
    val distanceX = -280.0 // Adjust the distance as needed
    val distanceY = -160.0

    val flying = new TranslateTransition {
      duration = frameDuration
      node = npcImage
      toX = npcImage.translateX() + distanceX
      toY = npcImage.translateY() + distanceY
    }
    flying.play()
  }

  def inGame(npcImage: ImageView): Unit = {
    val dragonFiring = new Image(getClass.getResourceAsStream("/images/Dragon/dragonGame.png"))

    val frameDuration = Duration(800)
    val rotationAngleMin = -150.0
    val rotationAngleMax = 100.0

    val random = new Random()

    val rotating = new RotateTransition {
      duration = frameDuration
      node = npcImage
      byAngle = random.nextDouble() * (rotationAngleMax - rotationAngleMin) + rotationAngleMin // Rotate by the full angle
      interpolator = Interpolator.Linear // Use linear interpolation for smooth rotation
      cycleCount = Animation.Indefinite // Indefinitely repeat the rotation
    }


    val translating = new TranslateTransition {
      duration = frameDuration
      node = npcImage
      //Dragon move randomly to avoid getting shoot
      val randomX = random.nextDouble() * (400 + 200) - 200 //from -200 to 400 in the X-axis
      val randomY = random.nextDouble() * (150 + 100) - 100 //from -50 to 300 in the y-axis
      toX = randomX
      toY = randomY
      interpolator = Interpolator.Linear
      cycleCount = 1
      onFinished = { _ =>
        inGame(npcImage) // Start a new round after this round finishes
      }
    }

    rotating.play()
    translating.play()
  }
}

