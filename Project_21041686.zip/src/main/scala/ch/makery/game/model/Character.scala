package ch.makery.game.model

import scalafx.scene.image.ImageView

// Common interface for characters
trait Character {
  def walk(npcImage: ImageView, distance: Double, cycleCount: Int): Unit
}


