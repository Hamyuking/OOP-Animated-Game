
package ch.makery.game.model

import scalafx.animation.{Interpolator, KeyFrame, Timeline, TranslateTransition}
import scalafx.scene.image.ImageView
import scalafx.scene.image.Image
import scalafx.util.Duration

class Princess extends Character {
  def walk(npcImage: ImageView, distance: Double, cycleCount: Int): Unit = {
    // Princess walking behavior
    val walkFrames: List[Image] = List(
      new Image(getClass.getResourceAsStream("/images/Princess/walk1.png")),
      new Image(getClass.getResourceAsStream("/images/Princess/walk2.png")),
      new Image(getClass.getResourceAsStream("/images/Princess/walk3.png")),
      new Image(getClass.getResourceAsStream("/images/Princess/walk4.png"))
    )

      val frameDuration = Duration(400)

    val walking = new Timeline {
      keyFrames = walkFrames.zipWithIndex.map {
        case (frame, index) =>
          KeyFrame(frameDuration * (index + 1), onFinished = { _ =>
            npcImage.image = frame
            npcImage.translateX = npcImage.translateX() + distance
          })
      }
    }

    walking.cycleCount = cycleCount
    walking.play()
  }

  def jump(npcImage: ImageView): Unit = {
    val initialY = npcImage.layoutY()

    val jumpDuration = Duration(150)

    val jumping = new Timeline {
      keyFrames = Seq(
        KeyFrame(jumpDuration, onFinished = { _ =>
          npcImage.layoutY = initialY - 20.0 //jump height
        }),
        KeyFrame(jumpDuration * 2, onFinished = { _ =>
          npcImage.layoutY = initialY
        })
      )
      cycleCount = 4 * 2 // Up and Down is one cycle
      autoReverse = true
    }

    jumping.play()
  }
}
