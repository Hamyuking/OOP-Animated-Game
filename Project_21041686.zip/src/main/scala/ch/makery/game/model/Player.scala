package ch.makery.game.model

import ch.makery.game.util.Database
import scalafx.beans.property.StringProperty
import scalikejdbc._
import scala.util.{Failure, Success, Try}

class Player(val playerNameS: String) extends Database {
  // Constructor
  def this() = this(null)

  // Properties
  var playerName = new StringProperty(playerNameS)

  def save(): Try[Int] = {
    if (!(isExist)) {
      Try(DB autoCommit { implicit session =>
        sql"""
          insert into player (playerName)
          values (${playerName.value})
        """.update.apply()
      })
    } else {
      Try(DB autoCommit { implicit session =>
        sql"""
          update player
          set
          playerName = ${playerName.value}
          where playerName = ${playerName.value}
        """.update.apply()
      })
    }
  }

  def isExist: Boolean = {
    DB readOnly { implicit session =>
      sql"""
        select * from player where
        playerName = ${playerName.value}
      """.map(rs => rs.string("playerName")).single.apply()
    } match {
      case Some(_) => true
      case None => false
    }
  }
}

object Player extends Database {
  def apply(playerNameS: String): Player = {
    new Player(playerNameS)
  }

  def initializeWarriorBoard(): Unit = {
    DB autoCommit { implicit session =>
      sql"""
        create table Player (
          id int not null GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
          playerName varchar(64)
        )
      """.execute.apply()
    }
  }

  def getAllPlayers: List[Player] = {
    DB readOnly { implicit session =>
      sql"select * from Player".map(rs => Player(rs.string("playerName"))).list.apply()
    }
  }
}
