package ch.makery.game.view

import ch.makery.game.MainApp
import scalafx.scene.image.{Image, ImageView}
import scalafx.animation.{KeyFrame, Timeline}
import scalafx.util.Duration
import scalafxml.core.macros.sfxml
import scalafx.scene.text.Text

@sfxml
class Scene3Controller (
                         private val storyS3a: Text,
                         private val storyS3b: Text,
                         private val dialogS3: ImageView
                       ) {


  def playS3(): Unit = {
    // Set initial position
    storyS3a.layoutX = 77.0
    storyS3a.layoutY = 299.0
    storyS3b.layoutX = 77.0
    storyS3b.layoutY = 299.0

    // Hide the story initially
    storyS3a.opacity = 0.0
    storyS3b.opacity = 0.0
    dialogS3.opacity = 0.0

    val storyTextS3a = "The Princess was stolen by the dragon."
    val storyTextS3b = "The King and the kingdom felt in depression.                               "

    // Typewriter effect
    val showStoryS3a = new Timeline {
      delay = Duration(800) //1000
      keyFrames = (0 until storyTextS3a.length).map { i =>
        KeyFrame(Duration(i * 100), onFinished = _ => {
          dialogS3.opacity = 1.0
          storyS3a.opacity = 1.0
          storyS3a.text = storyTextS3a.substring(0, i + 1)
        })
      }
      cycleCount = 1
    }
    showStoryS3a.play()

    val showStoryS3b = new Timeline {
      delay = Duration(8000) //sum of the delay in the same timeline
      keyFrames = (0 until storyTextS3b.length).map { i =>
        KeyFrame(Duration(i * 100), onFinished = _ => {
          storyS3a.opacity = 0.0
          storyS3b.opacity = 1.0
          storyS3b.text = storyTextS3b.substring(0, i + 1)
        })
      }
      cycleCount = 1
    }
    showStoryS3b.play()

    val animation = new Timeline {
      delay = Duration(1000)
      keyFrames = Seq(
        KeyFrame(Duration(13000), onFinished = _ => {
          MainApp.switchScene4()
        })
      )
    }
    animation.play()
  }
}