package ch.makery.game.view

import ch.makery.game.MainApp
import scalafxml.core.macros.sfxml
import scalafx.event.ActionEvent
import scalafx.scene.input.MouseEvent
import scalafx.scene.media.{Media, MediaPlayer}

@sfxml
class InformationPageController() {
  def playSoundEffect(soundPath: String): Unit = {
    val soundEffect = new Media(getClass.getResource(soundPath).toExternalForm)
    val mediaPlayer = new MediaPlayer(soundEffect)
    mediaPlayer.play()
  }

  def backLanding(event: MouseEvent): Unit = {
    playSoundEffect("/sound/Pop.wav")
    MainApp.showLandingPage()
  }

  def startGame(event: MouseEvent): Unit = {
    playSoundEffect("/sound/Pop.wav")
    MainApp.playScene1()
  }
}
