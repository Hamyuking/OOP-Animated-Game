package ch.makery.game.view

import java.util.Timer
import java.util.TimerTask
import ch.makery.game.MainApp
import ch.makery.game.MainApp.stage
import ch.makery.game.model.Dragon
import scalafx.application.Platform
import scalafx.scene.control.Alert.AlertType
import scalafx.scene.control.{Alert, ButtonType, Label, ProgressBar}
import scalafx.scene.image.ImageView
import scalafx.scene.input.MouseEvent
import scalafxml.core.macros.sfxml

@sfxml
class GameplayController (
                           private var pointer : ProgressBar,
                           private var timer: ProgressBar,
                           private var point1 : Double,
                           private val dragonGameplay: ImageView,
                         ) {

  //Initialize 30s timer
  private val timeLimitSeconds = 30 // Set the time limit to 60 seconds
  private var remainingTime = timeLimitSeconds.toDouble
  private val timerIntervalMillis = 1000 // Update timer every second
  private var timerTask: TimerTask = _
  timer.setProgress(1.0) // Start with full timer

  //Initialize pointer
  pointer.setProgress(0)

  val dragonGameScene = new Dragon()
  dragonGameScene.inGame(dragonGameplay)

  timerTask = new TimerTask {
    override def run(): Unit = {
      remainingTime -= 1
      val progress = remainingTime / timeLimitSeconds
      timer.setProgress(progress)

      if (remainingTime <= 0) {
        timerTask.cancel() // Stop the timer task
        showTimeUpDialog()
      }
    }
  }

  // Start the timer
  val timer1 = new Timer(true)
  timer1.scheduleAtFixedRate(timerTask, timerIntervalMillis, timerIntervalMillis)

  def shootingAction(event: MouseEvent): Unit = {
    if (point1 > 0 || point1 == 0) {
      point1 += 0.02
      pointer.setProgress(point1)
    }
    if (point1 > 1) {
      timer1.cancel() // Stop the timer
      showGameCompletedDialog()
    }
  }

  private def resetGame(): Unit = {
    MainApp.startGame()
  }

  private def switchToEndingPage(): Unit = {
    MainApp.showEndingPage()
  }

  private def showTimeUpDialog(): Unit = {
    Platform.runLater(() => {
      val alert = new Alert(AlertType.Warning) {
        initOwner(stage)
        title = "Time's Up"
        headerText = "You failed to defeat the Dragon."
        contentText = "Game over."

        val tryAgainButton = new ButtonType("Try Again")
        val switchToEndingPageButton = new ButtonType("End Game")
        buttonTypes = Seq(tryAgainButton, switchToEndingPageButton)
      }

      val result = alert.showAndWait()

      result match {
        case Some(buttonType) if buttonType == alert.buttonTypes.head => resetGame() // Implement your reset game logic here
        case Some(buttonType) if buttonType == alert.buttonTypes(1) => switchToEndingPage() // Implement your switch to ending page logic here
        case _ => // Do nothing or handle other cases if needed
      }
    })
  }

  //Score full before 30s end
  private def showGameCompletedDialog(): Unit = {
    val alert = new Alert(AlertType.Information) {
      initOwner(stage)
      title = "Congratulations"
      headerText = "You have defeated the Dragon!"
      contentText = "Continue your quest to find the Princess."
    }
    alert.showAndWait()
    MainApp.switchScene6()
  }
}
