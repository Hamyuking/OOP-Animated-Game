package ch.makery.game.view

import ch.makery.game.MainApp
import scalafx.scene.image.{Image, ImageView}
import scalafx.animation.{KeyFrame, Timeline, TranslateTransition}
import scalafx.beans.property.BooleanProperty
import scalafx.util.Duration
import scalafxml.core.macros.sfxml
import scalafx.scene.text.Text

@sfxml
class Scene4bController (
                          private val bgS4b: ImageView,
                          private val storyS4b: Text,
                          private val storyS4c: Text,
                          private val dialogS4b: ImageView,
                          private val warriorS4b: ImageView
                        ) {

  def playS4b(): Unit = {
    val imageStream = getClass.getResourceAsStream("/images/Background/Scene4.png")
    val image = new Image(imageStream)
    bgS4b.image = image

    // Hide the story initially
    storyS4b.opacity = 0.0
    storyS4c.opacity = 0.0
    dialogS4b.opacity = 0.0
    warriorS4b.opacity = 0.0

    // Set initial position of the background
    bgS4b.layoutX = 0.0
    bgS4b.layoutY = 100.0

    // Sliding effect
    val sld = new TranslateTransition(Duration(1000), bgS4b) {
      byY = -100.0
      cycleCount = 1
      autoReverse = true
    }
    sld.play()

    val storyTextS4b = "Your majesty, I am a warrior."
    val storyTextS4c = "It would be my pleasure to save the Princess.            "

    sld.onFinished = _ => {
      val showStoryS4b = new Timeline {
        delay = Duration(500)
        keyFrames = (0 until storyTextS4b.length).map { i =>
          KeyFrame(Duration(i * 100), onFinished = _ => {
            warriorS4b.opacity = 1.0
            dialogS4b.opacity = 1.0
            storyS4b.opacity = 1.0
            storyS4b.text = storyTextS4b.substring(0, i + 1)
          })
        }
        cycleCount = 1
      }
      showStoryS4b.play()

      // Typewriter effect for storyS4c
      showStoryS4b.onFinished = _ => {
        val showStoryS4c = new Timeline {
          delay = Duration(2000)
          keyFrames = (0 until storyTextS4c.length).map { i =>
            KeyFrame(Duration(i * 100), onFinished = _ => {
              storyS4b.opacity = 0.0
              storyS4c.layoutX = 99.0
              storyS4c.layoutY = 304.0
              storyS4c.opacity = 1.0
              storyS4c.text = storyTextS4c.substring(0, i + 1)
            })
          }
          cycleCount = 1
        }
        showStoryS4c.play()

        val animation = new Timeline {
          delay = Duration(1000)
          keyFrames = Seq(
            KeyFrame(Duration(7000), onFinished = _ => {
              MainApp.switchScene5()
            })
          )
        }
        animation.play()
      }
    }
  }
}
