package ch.makery.game.view

import ch.makery.game.MainApp
import scalafx.animation.{KeyFrame, Timeline}
import scalafx.scene.image.ImageView
import scalafx.scene.text.Text
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene8bController(
                         private val storyS8b: Text,
                         private val dialogS8b: ImageView,
                         private val princessNPC: ImageView
                       ) {

  def playS8b(): Unit = {

    princessNPC.opacity = 0.0
    dialogS8b.opacity = 0.0
    storyS8b.opacity = 0.0

    val storyTextS8b = "But I need no one to save me. I can save myself."

    // Typewriter effect
    val showStoryS8b = new Timeline {
      delay = Duration(1000)
      keyFrames = (0 until storyTextS8b.length).map { i =>
        KeyFrame(Duration(i * 100), onFinished = _ => {
          princessNPC.opacity = 1.0
          dialogS8b.opacity = 1.0
          storyS8b.opacity = 1.0
          storyS8b.text = storyTextS8b.substring(0, i + 1)
        })
      }
      cycleCount = 1
    }
    showStoryS8b.play()

    val animation = new Timeline {
      delay = Duration(1000)
      keyFrames = Seq(
        KeyFrame(Duration(8000), onFinished = _ => {
          MainApp.switchScene8c()
        })
      )
    }
    animation.play()
  }
}
