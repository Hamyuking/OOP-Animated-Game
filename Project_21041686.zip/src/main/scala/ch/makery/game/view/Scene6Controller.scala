package ch.makery.game.view

import ch.makery.game.MainApp
import scalafx.scene.image.{Image, ImageView}
import scalafx.animation.{KeyFrame, Timeline, TranslateTransition}
import scalafx.scene.text.Text
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene6Controller (
                         private val bgS6: ImageView,
                         private val warriorS6: ImageView,
                         private val storyS6: Text,
                         private val dialogS6: ImageView,
                       ) {

  def playS6(): Unit = {
    val imageStream = getClass.getResourceAsStream("/images/Background/Scene6.gif")
    val image = new Image(imageStream)
    bgS6.image = image

    // Hide the story initially
    storyS6.opacity = 0.0
    dialogS6.opacity = 0.0
    warriorS6.opacity = 0.0

    // Set initial position of the background
    bgS6.layoutX = 0.0
    bgS6.layoutY = 50.0

    // Sliding effect
    val sld = new TranslateTransition(Duration(1500), bgS6) {
      byY = -50.0
      cycleCount = 1
      autoReverse = true
    }
    sld.play()

    val storyTextS6 = "I won so give us back the Princess!          "

    sld.onFinished = _ => {
      // Typewriter effect
      val showStoryS6 = new Timeline {
        delay = Duration(1000)
        keyFrames = (0 until storyTextS6.length).map { i =>
          KeyFrame(Duration(i * 100), onFinished = _ => {
            warriorS6.opacity = 1.0
            dialogS6.opacity = 1.0
            storyS6.opacity = 1.0
            storyS6.text = storyTextS6.substring(0, i + 1)
          })
        }
        cycleCount = 1
      }
      showStoryS6.play()

      val animation = new Timeline {
        delay = Duration(1000)
        keyFrames = Seq(
          KeyFrame(Duration(5500), onFinished = _ => {
            MainApp.switchScene6b()
          })
        )
      }
      animation.play()
    }
  }
}