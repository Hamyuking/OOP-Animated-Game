package ch.makery.game.view

import ch.makery.game.MainApp
import scalafx.scene.image.{Image, ImageView}
import scalafx.animation.{KeyFrame, Timeline, TranslateTransition}
import scalafx.scene.media.{Media, MediaPlayer}
import scalafx.util.Duration
import scalafxml.core.macros.sfxml
import scalafx.scene.text.Text

@sfxml
class Scene1Controller (
                         private val bgS1: ImageView,
                         private val storyS1a: Text,
                         private val storyS1b: Text,
                         private val dialogS1: ImageView
                       ) {


  def playS1(): Unit = {

    val imageStream = getClass.getResourceAsStream("/images/Background/Scene1.jpg")
    val image = new Image(imageStream)
    bgS1.image = image

    // Hide the story initially
    storyS1a.opacity = 0.0
    storyS1b.opacity = 0.0
    dialogS1.opacity = 0.0

    // Set initial position of the background
    bgS1.layoutX = 0.0
    bgS1.layoutY = -367.0

    // Sliding effect
    val bgSliding = new TranslateTransition(Duration(10000), bgS1) { //10000
      byY = 300.0
      cycleCount = 1
      autoReverse = true
    }
    bgSliding.play()

    val storyTexta = "Once upon a time, there is a kingdom full of fantasy where people live peacefully."
    val storyTextb = "Until one day...                   "

    // Typewriter effect
    val showStoryS1a = new Timeline {
      delay = Duration(10000) //10000
      keyFrames = (0 until storyTexta.length).map { i =>
        KeyFrame(Duration(i * 100), onFinished = _ => {
          dialogS1.opacity = 1.0
          storyS1a.opacity = 1.0
          storyS1a.text = storyTexta.substring(0, i + 1)
        })
      }
      cycleCount = 1
    }
    showStoryS1a.play()

    val showStoryS1b = new Timeline {
      delay = Duration(20000) //sum of the delay in the same timeline //20100
      keyFrames = (0 until storyTextb.length).map { i =>
        KeyFrame(Duration(i * 100), onFinished = _ => {
          storyS1a.opacity = 0.0
          storyS1b.layoutX = 77.0
          storyS1b.layoutY = 299.0
          storyS1b.opacity = 1.0
          storyS1b.text = storyTextb.substring(0, i + 1)
        })
      }
      cycleCount = 1
    }
    showStoryS1b.play()

    val animation = new Timeline {
      delay = Duration(13000)
      keyFrames = Seq(
        KeyFrame(Duration(10000), onFinished = _ => {
          MainApp.switchScene2()
        })
      )
    }
    animation.play()
  }


}
