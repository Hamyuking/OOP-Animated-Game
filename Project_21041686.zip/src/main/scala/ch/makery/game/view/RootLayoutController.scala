package ch.makery.game.view


import ch.makery.game.MainApp
import scalafx.animation.Timeline
import scalafx.scene.control.MenuBar
import scalafxml.core.macros.sfxml


@sfxml
class RootLayoutController() {

  def restart() = {
    MainApp.playScene1()
  }


  def backLanding() = {
    MainApp.showLandingPage()
  }

  def closeGame() = {
    System.exit(0)
  }
}

