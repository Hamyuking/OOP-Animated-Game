package ch.makery.game.view

import ch.makery.game.MainApp
import ch.makery.game.model.Warrior
import scalafx.scene.image.{Image, ImageView}
import scalafx.animation.{FadeTransition, Interpolator, KeyFrame, Timeline}
import scalafx.beans.property.BooleanProperty
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene4Controller (
                         private val bgS4: ImageView,
                         private val warriorNPC: ImageView,
                       ) {

  def playS4(): Unit = {
    val imageStream = getClass.getResourceAsStream("/images/Background/Scene4.png")
    val image = new Image(imageStream)
    bgS4.image = image

    // Set initial opacity
    bgS4.opacity = 0.0
    warriorNPC.opacity = 0.0

    // Fading effect
    val fd = new FadeTransition(Duration(2000), bgS4) { //500
      cycleCount = 1
      autoReverse = true
      interpolator = Interpolator.Linear
      fromValue = 1.0
      toValue = 0.0
    }
    fd.play()

    // Start Princess walking motion
    val warriorS4 = new Warrior()
    warriorNPC.opacity = 1.0
    warriorS4.walk(warriorNPC, 10.0, 2)

    val animation = new Timeline {
      delay = Duration(1000)
      keyFrames = Seq(
        KeyFrame(Duration(4000), onFinished = _ => {
          MainApp.switchScene4b()
        })
      )
    }
    animation.play()
  }
}