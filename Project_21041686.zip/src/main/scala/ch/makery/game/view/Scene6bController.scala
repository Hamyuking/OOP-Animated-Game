package ch.makery.game.view

import ch.makery.game.MainApp
import scalafx.animation.{KeyFrame, Timeline, TranslateTransition}
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.text.Text
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene6bController(
                         private val dragonNPC: ImageView,
                         private val dialogS6b: ImageView,
                         private val storyS6b: Text,
                       ) {

  def playS6b(): Unit = {
    // Hide the story initially
    storyS6b.opacity = 0.0
    dialogS6b.opacity = 0.0
    dragonNPC.opacity = 0.0

    val storyTextS6b = "Wait what? But the Princess defeated me and went back herself!"

    val showStoryS6b = new Timeline {
      delay = Duration(1000)
      keyFrames = (0 until storyTextS6b.length).map { i =>
        KeyFrame(Duration(i * 100), onFinished = _ => {
          dragonNPC.opacity = 1.0
          dialogS6b.opacity = 1.0
          storyS6b.opacity = 1.0
          storyS6b.text = storyTextS6b.substring(0, i + 1)
        })
      }
      cycleCount = 1
    }
    showStoryS6b.play()

    val animation = new Timeline {
      delay = Duration(1000)
      keyFrames = Seq(
        KeyFrame(Duration(8000), onFinished = _ => {
          MainApp.switchScene7()
        })
      )
    }
    animation.play()
  }
}