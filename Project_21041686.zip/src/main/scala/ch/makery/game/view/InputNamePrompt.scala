package ch.makery.game.view

import ch.makery.game.MainApp
import ch.makery.game.model.Player
import scalafx.event.ActionEvent
import scalafx.scene.control.{Alert, TextField}
import scalafx.stage.Stage
import scalafxml.core.macros.sfxml

@sfxml
class InputNamePrompt(private val playerNameField: TextField) {

  var dialogStage: Stage = null
  private var _player: Player = null
  var okClicked = false

  def player: Player = _player

  def player_=(x: Player): Unit = {
    _player = x
    playerNameField.text = _player.playerName.value
  }

  def handleOk(action: ActionEvent): Unit = {
    if (isInputValid()) {
      _player.playerName.value = playerNameField.text.value // Set player's name
      okClicked = true
      dialogStage.close()
    }
  }

  def handleCancel(action: ActionEvent): Unit = {
    dialogStage.close()
  }

  def nullChecking(x: String): Boolean = x == null || x.length == 0

  def isInputValid(): Boolean = {
    val errorMessage = "Please enter a valid name."
    if (nullChecking(playerNameField.text.value)) {
      val alert = new Alert(Alert.AlertType.Error) {
        initOwner(dialogStage)
        title = "Alert Message"
        headerText = "Empty name field!"
        contentText = errorMessage
      }
      alert.showAndWait()
      false
    } else {
      // Give instruction before starting the gameplay
      MainApp.player1.giveInstruction()
      true
    }
  }
}

