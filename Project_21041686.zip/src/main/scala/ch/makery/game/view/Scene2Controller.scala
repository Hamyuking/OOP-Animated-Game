package ch.makery.game.view

import ch.makery.game.MainApp
import ch.makery.game.model.{Dragon, Princess}
import scalafx.scene.image.{Image, ImageView}
import scalafx.animation.{FadeTransition, Interpolator, KeyFrame, Timeline}
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene2Controller (
                         private val bgS2: ImageView,
                         private val princessNPC: ImageView,
                         private val dragonNPC: ImageView
                       ) {

  def playS2(): Unit = {
    val imageStream = getClass.getResourceAsStream("/images/Background/Scene2.jpg")
    val image = new Image(imageStream)
    bgS2.image = image

    // Set initial opacity
    bgS2.opacity = 0.0
    princessNPC.opacity = 0.0
    dragonNPC.opacity = 0.0

    // Fading effect
    val fd = new FadeTransition(Duration(500), bgS2) {
      cycleCount = 1
      autoReverse = true
      interpolator = Interpolator.Linear
      fromValue = 0.0
      toValue = 1.0
    }
    fd.play()

    fd.onFinished = _ => {
      // Start Princess walking motion
      val princessS2 = new Princess()
      princessNPC.opacity = 1.0
      princessS2.walk(princessNPC, 20.0, 2)

      // Start Dragon flying motion
      val dragonS2 = new Dragon()
      dragonNPC.opacity = 1.0
      dragonS2.fly(dragonNPC)

      val animation = new Timeline {
        delay = Duration(1000)
        keyFrames = Seq(
          KeyFrame(Duration(5100), onFinished = _ => {
            MainApp.switchScene3()
          })
        )
      }
      animation.play()
    }
  }
}







