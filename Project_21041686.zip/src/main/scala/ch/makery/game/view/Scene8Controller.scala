package ch.makery.game.view

import ch.makery.game.MainApp
import scalafx.animation.{FadeTransition, Interpolator, KeyFrame, Timeline, TranslateTransition}
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.text.Text
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene8Controller(
                          private val bgS8: ImageView,
                          private val warriorNPC: ImageView,
                          private val storyS8: Text,
                          private val dialogS8: ImageView,
                        ) {

  def playS8(): Unit = {
    val imageStream = getClass.getResourceAsStream("/images/Background/Scene8.jpg")
    val image = new Image(imageStream)
    bgS8.image = image

    // Hide the story initially
    bgS8.opacity = 0.0
    storyS8.opacity = 0.0
    dialogS8.opacity = 0.0
    warriorNPC.opacity = 0.0

    // Fading effect
    val fd = new FadeTransition(Duration(1000), bgS8) {
      cycleCount = 1
      autoReverse = true
      interpolator = Interpolator.Linear
      fromValue = 0.0
      toValue = 1.0
    }
    fd.play()

    val storyTextS8 = "Your highness, I am the Warrior who just back from the quest to save you..."

    fd.onFinished = _ => {
      val showStoryS8 = new Timeline {
        delay = Duration(500)
        keyFrames = (0 until storyTextS8.length).map { i =>
          KeyFrame(Duration(i * 100), onFinished = _ => {
            warriorNPC.opacity = 1.0
            dialogS8.opacity = 1.0
            storyS8.opacity = 1.0
            storyS8.text = storyTextS8.substring(0, i + 1)
          })
        }
        cycleCount = 1
      }
      showStoryS8.play()

      val animation = new Timeline {
        delay = Duration(1000)
        keyFrames = Seq(
          KeyFrame(Duration(9000), onFinished = _ => {
            MainApp.switchScene8b()
          })
        )
      }
      animation.play()
    }
  }
}
