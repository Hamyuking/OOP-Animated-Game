package ch.makery.game.view

import ch.makery.game.MainApp
import ch.makery.game.model.{Dragon, Princess}
import scalafx.animation.{FadeTransition, Interpolator, KeyFrame, Timeline}
import scalafx.scene.image.{Image, ImageView}
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene7Controller(
                         private val bgS7: ImageView,
                         private val princessNPC: ImageView,
                         private val dragonNPC: ImageView
                       ) {

  def playS7(): Unit = {
    val imageStream = getClass.getResourceAsStream("/images/Background/Scene2.jpg")
    val image = new Image(imageStream)
    bgS7.image = image

    // Set initial opacity
    bgS7.opacity = 0.0
    princessNPC.opacity = 0.0
    dragonNPC.opacity = 0.0

    // Fading effect
    val fd = new FadeTransition(Duration(1000), bgS7) {
      cycleCount = 1
      autoReverse = true
      interpolator = Interpolator.Linear
      fromValue = 0.0
      toValue = 1.0
    }
    fd.play()

    val delayDuration = Duration(1000) // Adjust the delay duration as needed

    val defectDragon = new Timeline {
      keyFrames = Seq(
        KeyFrame(delayDuration, onFinished = _ => {
          dragonNPC.opacity = 1.0
          val princessS8 = new Princess()
          princessNPC.opacity = 1.0
          princessS8.jump(princessNPC)

          val sceneSwitchDuration = Duration(3000) // Adjust the scene switch duration as needed
          val sceneSwitchAnimation = new Timeline {
            keyFrames = Seq(
              KeyFrame(sceneSwitchDuration, onFinished = _ => {
                MainApp.switchScene8()
              })
            )
          }
          sceneSwitchAnimation.play()
        })
      )
    }
    defectDragon.play()
  }
}







