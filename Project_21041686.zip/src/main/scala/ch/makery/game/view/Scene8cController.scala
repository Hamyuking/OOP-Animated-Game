
package ch.makery.game.view

import ch.makery.game.MainApp
import ch.makery.game.model.{Dragon, Princess}
import scalafx.animation.{FadeTransition, Interpolator, KeyFrame, Timeline}
import scalafx.beans.property.{BooleanProperty, IntegerProperty}
import scalafx.scene.image.{Image, ImageView}
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

@sfxml
class Scene8cController(
                         private val princessNPC: ImageView
                       ) {


  def playS8c(): Unit = {
    val imageStream = getClass.getResourceAsStream("/images/Background/Scene8.jpg")
    val image = new Image(imageStream)

    // Start Princess walking motion
    val princessS8 = new Princess()

    princessS8.walk(princessNPC, 30.0, 3)


    val animation = new Timeline {
      delay = Duration(1000)
      keyFrames = Seq(
        KeyFrame(Duration(5000), onFinished = _ => {
          MainApp.showEndingPage()
        })
      )
    }
    animation.play()
  }
}





