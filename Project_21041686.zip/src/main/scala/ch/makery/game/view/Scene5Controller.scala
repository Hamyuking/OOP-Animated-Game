package ch.makery.game.view

import ch.makery.game.MainApp
import ch.makery.game.model.Player
import scalafx.scene.image.ImageView
import scalafx.animation.{KeyFrame, Timeline}
import scalafx.event.ActionEvent
import scalafx.scene.control.Button
import scalafx.util.Duration
import scalafxml.core.macros.sfxml
import scalafx.scene.text.Text

@sfxml
class Scene5Controller(
                          private val storyS5: Text,
                          private val dialogS5: ImageView,
                          private val kingNPC: ImageView,
                          private val answerButton: Button
                        ) {

  def playS5(): Unit = {
    // Hide the story initially
    storyS5.opacity = 0.0
    dialogS5.opacity = 0.0
    kingNPC.opacity = 0.0
    answerButton.opacity = 0.0

    val storyTextS5 = "Young warrior, what is your name?                "

    // Typewriter effect
    val showStoryS5 = new Timeline {
      delay = Duration(1000)
      keyFrames = (0 until storyTextS5.length).map { i =>
        KeyFrame(Duration(i * 100), onFinished = _ => {
          kingNPC.opacity = 1.0
          dialogS5.opacity = 1.0
          storyS5.opacity = 1.0
          storyS5.text = storyTextS5.substring(0, i + 1)
        })
      }
      cycleCount = 1
    }
    showStoryS5.play()

    showStoryS5.setOnFinished(_ => {
      answerButton.opacity = 1.0
    })
  }

  def handleNewPlayer (action: ActionEvent) = {
    val player = new Player (playerNameS = "")
    val okClicked = MainApp.showDialog(player);
    if (okClicked) {
      MainApp.playerData += player
      player.save()
    }

  }
}





