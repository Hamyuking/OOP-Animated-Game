package ch.makery.game.view

import ch.makery.game.MainApp
import scalafxml.core.macros.sfxml
import scalafx.scene.input.MouseEvent
import scalafx.scene.media.{Media, MediaPlayer}

@sfxml
class LandingPageController() {

  def playSoundEffect(soundPath: String): Unit = {
    val soundEffect = new Media(getClass.getResource(soundPath).toExternalForm)
    val mediaPlayer = new MediaPlayer(soundEffect)
    mediaPlayer.play()
  }

  def startGame(event: MouseEvent): Unit = {
    playSoundEffect("/sound/Pop.wav")
    MainApp.playScene1()
  }

  def showInfo(event: MouseEvent): Unit = {
    playSoundEffect("/sound/Pop.wav")
    MainApp.showInformationPage()
  }

  def showWarrior(event: MouseEvent): Unit = {
    playSoundEffect("/sound/Pop.wav")
    MainApp.showWarriorBoard()
  }
}

