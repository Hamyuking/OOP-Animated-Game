package ch.makery.game.view

import ch.makery.game.MainApp
import ch.makery.game.MainApp.playerData
import scalafxml.core.macros.sfxml
import ch.makery.game.model.Player
import scalafx.scene.control.{Button, TableColumn, TableView, TextField}
import scalafx.event.ActionEvent
import scalafx.scene.input.MouseEvent
import scalafx.scene.media.{Media, MediaPlayer}

@sfxml
class WarriorBoardController (
                               private val handleClearRecord: Button,
                               private val warriorBoard: TableView[Player],
                               private val playerNameColumn: TableColumn[Player, String]
                             ) {

  // initialize Table View display contents model
  warriorBoard.items = MainApp.playerData

  // initialize columns's cell values
  playerNameColumn.cellValueFactory = {
    _.value.playerName
  }

  def playSoundEffect(soundPath: String): Unit = {
    val soundEffect = new Media(getClass.getResource(soundPath).toExternalForm)
    val mediaPlayer = new MediaPlayer(soundEffect)
    mediaPlayer.play()
  }

  def handleClearRecord(action: ActionEvent): Unit = {
    // Clear the input fields
    playerData.clear()
  }

  def backLanding(event: MouseEvent): Unit = {
    playSoundEffect("/sound/Pop.wav")
    MainApp.showLandingPage()
  }
}



